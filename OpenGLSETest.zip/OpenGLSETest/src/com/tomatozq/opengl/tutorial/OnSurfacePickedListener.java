package com.tomatozq.opengl.tutorial;

public interface OnSurfacePickedListener {

	void onSurfacePicked(int which);

}
